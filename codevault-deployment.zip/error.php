<?php include 'includes/header.php'; ?>

<div class="alert alert-danger">
    <h2>Error</h2>
    <p>Sorry, an unexpected error occurred. Please try again later.</p>
    <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
</div>

<?php include 'includes/footer.php'; ?>